<?php
include("navbar.php");
include("../database/connection.php"); // Include your database connection file

$select = mysqli_query($conn, "SELECT * FROM `user` WHERE user_id = '$user_id'") or die('Query failed');
if (mysqli_num_rows($select) > 0) {
    $fetch = mysqli_fetch_assoc($select);
} else {
    die("User not found in database.");
}


// Handle user search request
if (isset($_POST['query'])) {
    $search = mysqli_real_escape_string($conn, $_POST['query']);
    $sql = "SELECT user_id, Fname, Lname FROM user WHERE Fname LIKE '%$search%' OR Lname LIKE '%$search%' LIMIT 5";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<li class='list-group-item list-item' data-id='" . $row['user_id'] . "'>" . htmlspecialchars($row['Fname'] . " " . $row['Lname']) . "</li>";
        }
    } else {
        echo "<li class='list-group-item'>No results found</li>";
    }
    exit;
}

// Handle Serial Card & Expiration Date submission
if (isset($_POST['registerUser'])) {
    $userId = mysqli_real_escape_string($conn, $_POST['userId']);
    $serialCard = mysqli_real_escape_string($conn, $_POST['serialCard']);
    $expirationDate = mysqli_real_escape_string($conn, $_POST['computedExpirationDate']); // Get computed date

    // Check if user exists
    $checkQuery = "SELECT * FROM user WHERE user_id = '$userId'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // Update user record with computed expiration date
        $updateQuery = "UPDATE user SET
            SerialCard = '$serialCard',
            CardExpiration = '$expirationDate',
            DateRegistered = CURDATE()  -- Stores only the current date (YYYY-MM-DD)
            WHERE user_id = '$userId'";

        if (mysqli_query($conn, $updateQuery)) {
            echo "✅ Registration successful!";
        } else {
            echo "❌ Error: " . mysqli_error($conn);
        }
    } else {
        echo "❌ User not found!";
    }
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user_id'])) {
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $Fname = mysqli_real_escape_string($conn, $_POST['Fname']);
    $Lname = mysqli_real_escape_string($conn, $_POST['Lname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $points = mysqli_real_escape_string($conn, $_POST['points']);

    // Update query
    $sql = "UPDATE user SET Fname='$Fname', Lname='$Lname', email='$email', address='$address', contact='$contact', role='$role', points ='$points' WHERE user_id='$user_id'";

    if (mysqli_query($conn, $sql)) {
        header("Location:member.php"); // Redirect back to the user list
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="styles.css">
    <title>User Management</title>
</head>
<body>
<section class="main-content">
  <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="mb-0">Member List</h2>
  </div>

  <table class="table table-bordered table-hover">
      <thead class="table-dark">
          <tr>
              <th>ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Address</th>
              <th>Contact</th>
              <th>Role</th>
              <th>Status</th>
              <th>Code</th>
              <th>Points</th>
              <th>Serial Card</th>
              <th>Registered Date</th>
              <th>Card Expiration</th>
              <th>Actions</th>
          </tr>
      </thead>
      <tbody>
          <?php
          $sql = "SELECT * FROM user WHERE role = 'member' ";
          $result = mysqli_query($conn, $sql);

          if (mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>";
                  echo "<form action='member.php' method='POST'>";
                  echo "<input type='hidden' name='user_id' value='" . $row['user_id'] . "'>";
                  echo "<td>" . htmlspecialchars($row['user_id']) . "</td>";

                  // Editable fields
                  echo "<td><input type='text' class='form-control' name='Fname' value='" . htmlspecialchars($row['Fname']) . "'></td>";
                  echo "<td><input type='text' class='form-control' name='Lname' value='" . htmlspecialchars($row['Lname']) . "'></td>";
                  echo "<td><input type='email' class='form-control' name='email' value='" . htmlspecialchars($row['email']) . "'></td>";
                  echo "<td><input type='text' class='form-control' name='address' value='" . htmlspecialchars($row['address']) . "'></td>";
                  echo "<td><input type='text' class='form-control' name='contact' value='" . htmlspecialchars($row['contact']) . "'></td>";

                  // Role selection dropdown
                  echo "<td>
                          <select name='role' class='form-select'>
                              <option value='user' " . ($row['role'] == 'user' ? 'selected' : '') . ">User</option>
                              <option value='member' " . ($row['role'] == 'member' ? 'selected' : '') . ">Member</option>
                              <option value='admin' " . ($row['role'] == 'admin' ? 'selected' : '') . ">Admin</option>
                          </select>
                        </td>";

                  echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['code']) . "</td>";
                    echo "<td><input type='text' class='form-control' name='points' value='" . htmlspecialchars($row['points']) . "'></td>";
                    echo "<td>" . htmlspecialchars($row['SerialCard']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['DateRegistered']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['CardExpiration']) . "</td>";

                  // Save Button
                  echo "<td>
                          <button type='submit' class='btn btn-sm btn-success'>
                              <i class='fa-solid fa-floppy-disk'></i> Save
                          </button>
                        </td>";
                  echo "</form>";
                  echo "</tr>";
              }
          } else {
              echo "<tr><td colspan='11' class='text-center'>No users found</td></tr>";
          }

          mysqli_close($conn);
          ?>
      </tbody>
  </table>

  <!-- Register Button Centered Below Table -->
  <div class="d-flex justify-content-center mt-4">
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#userModal">
          <i class="fas fa-user-plus"></i> Register
      </button>
  </div>

<!-- Modal -->
<!-- <div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="userModalLabel">Register Account</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="userForm">
          <div class="mb-3">
            <label for="accountName" class="form-label" >user ID</label>
            <input type="text" class="form-control" id="accountName" name="accountName" required>
          </div>
          <div class="mb-3">
            <label for="serialCard" class="form-label">Serial Card</label>
            <input type="text" class="form-control" id="serialCard" name="serialCard" required>
          </div>
          <div class="mb-3">
            <label for="expirationDate" class="form-label">Expiration Date</label>
            <select class="form-control" id="expirationDate" name="expirationDate" required>
              <option value="">Select Membership Period</option>
              <option value="3 Months">3 Months</option>
              <option value="6 Months">6 Months</option>
              <option value="1 Year">1 Year</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary">Register</button>
        </form>
      </div>
    </div>
  </div>
</div> -->

<!-- Modal -->
<div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="userModalLabel">Register Account</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="userForm">
          <div class="mb-3 position-relative">
            <label for="accountName" class="form-label">Account Name</label>
            <input type="text" class="form-control" id="accountName" name="accountName" autocomplete="off" required>
            <ul id="userList" class="list-group position-absolute w-100"></ul>
          </div>
          <div class="mb-3">
            <label for="serialCard" class="form-label">Serial Card</label>
            <input type="text" class="form-control" id="serialCard" name="serialCard" required>
          </div>
          <div class="mb-3">
            <label for="expirationDate" class="form-label">Expiration Date</label>
            <select class="form-control" id="expirationDate" name="expirationDate" required>
              <option value="">Select Membership Period</option>
              <option value="3">3 Months</option>
              <option value="6">6 Months</option>
              <option value="12">1 Year</option>
            </select>
          </div>

          <!-- Hidden input for computed expiration date -->
          <input type="hidden" id="computedExpirationDate" name="computedExpirationDate">

          <button type="submit" class="btn btn-primary">Register</button>
        </form>
      </div>
    </div>
  </div>
</div>
</section>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function () {
    let selectedUserId = ""; // Store selected user ID

    // Live search for users
    $("#accountName").on("input", function () {
        let query = $(this).val();
        if (query.length > 0) {
            $.ajax({
                url: "", // Same page request
                method: "POST",
                data: { query: query },
                success: function (data) {
                    $("#userList").html(data).show();
                }
            });
        } else {
            $("#userList").hide();
        }
    });

    // Select a user from the dropdown
    $(document).on("click", ".list-item", function () {
        selectedUserId = $(this).data("id"); // Capture user ID
        let fullName = $(this).text();

        $("#accountName").val(fullName);
        $("#userList").hide();
    });

    // Hide dropdown when clicking outside
    $(document).click(function (e) {
        if (!$(e.target).closest("#accountName, #userList").length) {
            $("#userList").hide();
        }
    });

    // Compute expiration date when membership period is selected
    $("#expirationDate").change(function () {
        let selectedMonths = parseInt($(this).val());
        if (!selectedMonths) {
            $("#computedExpirationDate").val("");
            return;
        }

        let today = new Date();
        today.setMonth(today.getMonth() + selectedMonths);

        let formattedDate = today.toISOString().split('T')[0];
        $("#computedExpirationDate").val(formattedDate);
    });

    // Handle form submission
    $("#userForm").on("submit", function (event) {
        event.preventDefault(); // Prevent page reload

        let serialCard = $("#serialCard").val();
        let computedExpirationDate = $("#computedExpirationDate").val();

        if (!selectedUserId) {
            alert("Please select a valid user before registering!");
            return;
        }

        $.ajax({
            url: "", // Same page request
            method: "POST",
            data: {
                registerUser: true,
                userId: selectedUserId,
                serialCard: serialCard,
                computedExpirationDate: computedExpirationDate
            },
            success: function (response) {
                alert(response); // Show success/error message
                var modal = bootstrap.Modal.getInstance(document.getElementById('userModal'));
                modal.hide();
                $("#userForm")[0].reset(); // Clear form
            }
        });
    });
});
</script>



</body>
</html>
