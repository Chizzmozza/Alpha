<?php
include("navbar.php");
include("../database/connection.php"); // Include your database connection file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="styles.css">
    <title>Registered Member</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            margin-left: 230px;
            height: 100vh;
            background-color: #d3d3d3;
            padding-top: 50px;
        }
        .container {
            width: 80%;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .table-container {
            width: 100%;
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center">Registered Members</h2>
        <div class="table-container">
            <div class="table-responsive">
                <table class="table table-striped table-bordered text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>Serial Number</th>
                            <th>Name</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Points</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>SN001</td>
                            <td>John Doe</td>
                            <td>08:00 AM</td>
                            <td>04:00 PM</td>
                            <td>100</td>
                        </tr>
                        <tr>
                            <td>SN002</td>
                            <td>Jane Smith</td>
                            <td>09:30 AM</td>
                            <td>05:30 PM</td>
                            <td>150</td>
                        </tr>
                        <tr>
                            <td>SN003</td>
                            <td>Michael Brown</td>
                            <td>10:15 AM</td>
                            <td>06:00 PM</td>
                            <td>200</td>
                        </tr>
                        <tr>
                            <td>SN004</td>
                            <td>Emily Johnson</td>
                            <td>07:45 AM</td>
                            <td>03:45 PM</td>
                            <td>180</td>
                        </tr>
                        <tr>
                            <td>SN005</td>
                            <td>Chris Wilson</td>
                            <td>08:30 AM</td>
                            <td>04:30 PM</td>
                            <td>130</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
